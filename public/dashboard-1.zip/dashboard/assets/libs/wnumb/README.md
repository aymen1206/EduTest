wnumb
=====

wNumb - JavaScript Number &amp; Money formatting

# Documentation

Documentation and examples are available on [refreshless.com/wnumb](http://refreshless.com/wnumb/).

# Changelog

### 1.1.0 (*2017-02-04*)
- Changed: Renamed `postfix` option to the proper `suffix`. `postfix` is remapped internally for backward compatibility;

# License

Licensed [WTFPL](http://www.wtfpl.net/about/), so free for personal and commercial use.
